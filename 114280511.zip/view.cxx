#include "view.hxx"

// Convenient type aliases:
using Color = ge211::Color;
using Sprite_set = ge211::Sprite_set;

// You can change this or even determine it some other way:
static int const grid_size = 36;
static int const grid_size2 = 33;
static int const circle_radius = 13;

static ge211::Color const dark_color {0, 0, 0};
static ge211::Color const light_color {255, 255, 255};
static ge211::Color const green_block_color {0, 255, 0};
static ge211::Color const red_block_color {255, 0, 0};
static ge211::Color const light_turn_color {255, 255, 255};
static ge211::Color const dark_turn_color {0, 0, 0};
static ge211::Color const grey_block_color {128, 128, 128};



View::View(Model const& model)
        : model_(model),
          light_player_sprite(circle_radius, light_color),
          dark_player_sprite(circle_radius, dark_color),
          green_block_sprite({grid_size2, grid_size2}, green_block_color),
          red_block_sprite({grid_size2, grid_size2}, red_block_color),
          light_turn_sprite(circle_radius / 3, light_turn_color),
          dark_turn_sprite(circle_radius / 3, dark_turn_color),
          grey_block_sprite({grid_size2, grid_size2}, grey_block_color)
        // You may want to add sprite initialization here
{ }

void View::draw(Sprite_set& set, ge211::Posn<int> mouse_pos)
{
    mouse_pos = screen_to_board(mouse_pos);

    for (auto pos : model_.board()){

        set.Sprite_set::add_sprite(green_block_sprite, board_to_screen(pos), 0);

        if (Player::dark == model_.operator[](pos)) {
            if (model_.winner() == Player::dark) {
                set.Sprite_set::add_sprite(grey_block_sprite, board_to_screen(pos), 1);
            }

            pos = board_to_screen(pos);
            pos.x += 3;
            pos.y += 3;
            set.Sprite_set::add_sprite(dark_player_sprite, pos , 2);

        } else if (Player::light == model_.operator[](pos)) {
            if (model_.winner() == Player::light) {
                set.Sprite_set::add_sprite(grey_block_sprite, board_to_screen(pos), 1);
            }

            pos = board_to_screen(pos);
            pos.x += 3;
            pos.y += 3;

            set.Sprite_set::add_sprite(light_player_sprite, pos, 2);

        }

    }

    const Move* move = model_.find_move(mouse_pos);

    if (model_.operator[](mouse_pos) == Player::neither && move == nullptr) {
        if (model_.turn() == Player::dark) {
            set.Sprite_set::add_sprite(dark_turn_sprite, board_to_screen(mouse_pos), 2);
        } else {
            set.Sprite_set::add_sprite(light_turn_sprite,board_to_screen(mouse_pos), 2);
        }
    } else if (model_.operator[](mouse_pos) == Player::neither) {
        for (Position pos : move->second) {
            set.Sprite_set::add_sprite(red_block_sprite, board_to_screen(pos), 1);
            if (model_.turn() == Player::dark) {
                mouse_pos = board_to_screen(mouse_pos);
                mouse_pos.x += 3;
                mouse_pos.y += 3;
                set.Sprite_set::add_sprite(dark_player_sprite, mouse_pos, 2);
            } else {
                mouse_pos = board_to_screen(mouse_pos);
                mouse_pos.x += 3;
                mouse_pos.y += 3;
                set.Sprite_set::add_sprite(light_player_sprite, mouse_pos, 2);
            }
        }
    }
}


View::Position
View::board_to_screen(Position pos) const
{
    Position new_pos = {0, 0};

    new_pos.x = pos.x * grid_size;
    new_pos.y = pos.y * grid_size;

    return new_pos;
}

Model::Position
View::screen_to_board(Position pos) const
{
    Position new_pos = {0, 0};

    // new_pos.x = ceil(pos.x / grid_size);
    // new_pos.y = ceil(pos.y / grid_size);

    new_pos.x = pos.x / grid_size;
    new_pos.y = pos.y / grid_size;

    return new_pos;
}




View::Dimensions
View::initial_window_dimensions() const
{
    // You can change this if you want:
    return grid_size * model_.board().dimensions();
}

std::string
View::initial_window_title() const
{
    // You can change this if you want:
    return "Reversi";
}

